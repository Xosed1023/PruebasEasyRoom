export const pagination_options = {
    take: 10,
    page: 1
}