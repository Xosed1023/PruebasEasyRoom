export const motivosBloqueoMesa = [
    "Reservación",
    "Fuera de servicio",
    "Mantenimiento",
]