export const ROOM_STATUS = {
    limpia: "Limpia",
    preparada: "Preparada",
    ocupada: "Ocupada",
    bloqueada: "Bloqueada",
    reservada: "Reservada",
    sucia: "Sucia",
    supervision: "En supervisión",
}
