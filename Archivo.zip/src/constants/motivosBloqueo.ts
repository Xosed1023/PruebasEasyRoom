export const motivosBloqueo = [
    "Reparaciones",
    "Control de plagas",
    "Fallas técnicas",
    "Uso interno del hotel",
    "Fuerte olor de tabaco",
    "Ligero olor de tabaco",
    "Olor de tabaco verde",
    "Reserva",
    "Mal olor"
]
