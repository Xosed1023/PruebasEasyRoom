export const motivosMantenimiento = [
    "Mantenimiento general",
    "Desperfecto",
    "Fumigación",
    "Por reserva",
    "Tratamiento de agua",
    "Retrolavado",
    "Aire acondicionado",
    "Alto mantenimiento",
    "Por operación",
]
