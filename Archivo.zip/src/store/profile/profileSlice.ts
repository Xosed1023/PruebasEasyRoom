import { createSlice } from "@reduxjs/toolkit"
import { Configurations, Usuario } from "src/gql/schema"

export interface ProfileState {
    myProfile: Usuario
    hotel_id: string
    nombre_hotel: string
    logo_hotel: string
    zona_horaria: string
    usuario_id: string
    turno_id: string
    rolName: string
    estatus: string
    configurations?: Configurations
}

const initialState: ProfileState = {
    myProfile: JSON.parse(localStorage.getItem("myProfile") || "{}"),
    hotel_id: JSON.parse(localStorage.getItem("myProfile") || "{}")?.hotel?.[0]?.hotel_id,
    nombre_hotel: JSON.parse(localStorage.getItem("myProfile") || "{}")?.hotel?.[0]?.nombre_hotel,
    logo_hotel: JSON.parse(localStorage.getItem("myProfile") || "{}")?.hotel?.[0]?.logo_hotel || "",
    zona_horaria: JSON.parse(localStorage.getItem("myProfile") || "{}")?.hotel?.[0]?.zona_horaria,
    usuario_id: JSON.parse(localStorage.getItem("myProfile") || "{}")?.usuario_id,
    turno_id: JSON.parse(localStorage.getItem("myProfile") || "{}")?.turno?.turno_id,
    rolName: JSON.parse(localStorage.getItem("myProfile") || "{}")?.roles?.[0]?.nombre,
    estatus: JSON.parse(localStorage.getItem("myProfile") || "{}")?.estatus,
    configurations: JSON.parse(localStorage.getItem("myProfile") || "{}")?.hotel?.[0]?.configurations
}

export const profileSlice = createSlice({
    name: "profile",
    initialState,
    reducers: {
        setMyProfile: (state, action) => {
            // Redux Toolkit allows us to write "mutating" logic in reducers. It
            // doesn't actually mutate the state because it uses the Immer library,
            // which detects changes to a "draft state" and produces a brand new
            // immutable state based off those changes
            state.myProfile = action.payload
            state.hotel_id = action.payload?.hotel?.[0]?.hotel_id
            state.nombre_hotel = action.payload?.hotel?.[0]?.nombre_hotel
            state.logo_hotel = action.payload?.hotel?.[0]?.logo_hotel || ""
            state.zona_horaria = action.payload?.hotel?.[0]?.zona_horaria
            state.usuario_id = action.payload?.usuario_id
            state.turno_id = action.payload?.turno?.turno_id
            state.rolName = action.payload?.roles?.[0]?.nombre
            state.estatus = action.payload?.estatus
            state.configurations = action.payload?.hotel?.[0]?.configurations
        },
    },
})

// Action creators are generated for each case reducer function
export const { setMyProfile } = profileSlice.actions

export default profileSlice.reducer
