export const WITH_LOGOUT = "withLogout"
export const ROOMS_LENGTH_SKELETON = "@ROOMS_LENGTH_SKELETON" 
export const FIXED_ROOM_SIZE = "FIXED_ROOM_SIZE"