import { COLLECTION } from "../icons/Icon";

export type IconNameType = keyof typeof COLLECTION | (string & {})
