import { useMemo } from "react"
import { useModulos } from "./useModulos"
import { IconNameType } from "../types/IconNameType"

export const useMenuItems = (rolName, withEasyrewards, navigate, openModal) => {
    const { gastos } = useModulos()
    console.log(gastos)

    return useMemo<{ label: string; icon: IconNameType; onClick: () => void }[]>(() => {
        if (rolName === "VALETPARKING" || rolName === "RESTAURANTE") {
            return [...(withEasyrewards ? [{ label: "Easyrewards", icon: "giftFill", onClick: openModal }] : [])]
        }
        if (rolName === "COCINA") {
            return [{ label: "Inventario", icon: "packageFill", onClick: () => navigate("/u/inventario") }]
        }
        if (rolName === "ROOMSERVICE") {
            return [
                { label: "Incidencias", icon: "spamFill", onClick: () => navigate("/u/incidencias") },
                ...(withEasyrewards ? [{ label: "Easyrewards", icon: "giftFill", onClick: openModal }] : []),
            ]
        }
        if (rolName === "MANTENIMIENTO") {
            return [
                { label: "Mantenimiento", icon: "tools", onClick: () => navigate("/u/mantenimiento") },
                { label: "Incidencias", icon: "spamFill", onClick: () => navigate("/u/incidencias") },
            ]
        }
        return [
            { label: "Gastos", icon: "coinsFill", onClick: () => navigate("/u/gastos/table") },
            { label: "Cortes", icon: "changeDollar", onClick: () => navigate("/u/cortes") },
            { label: "Inventario", icon: "packageFill", onClick: () => navigate("/u/inventario") },
            { label: "Incidencias", icon: "spamFill", onClick: () => navigate("/u/incidencias") },
            { label: "Propinas", icon: "HandCoinFilled", onClick: () => navigate("/u/propinas") },
            ...(withEasyrewards ? [{ label: "Easyrewards", icon: "giftFill", onClick: openModal }] : []),
            { label: "Mantenimiento", icon: "tools", onClick: () => navigate("/u/mantenimiento") },
            // { label: "Reportes", icon: "dashboardFill", onClick: () => navigate("/u/reports") },
        ]
    }, [rolName, withEasyrewards, navigate, openModal])
}
