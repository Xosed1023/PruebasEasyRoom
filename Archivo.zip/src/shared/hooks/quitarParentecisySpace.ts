export const quitarParentesisYEspacios = (cadena: string): string => cadena.replace(/[() \s]/g, "")
