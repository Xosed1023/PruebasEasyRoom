import { IconNamesProps } from "./Icon"

const clipboard = (props: IconNamesProps) => (
    <svg xmlns="http://www.w3.org/2000/svg" width={24} height={24} fill="none" viewBox="0 0 24 24" {...props}>
        <path
            fill="#0E0E0E"
            d="M6 4v4h12V4h2.007c.548 0 .993.445.993.993v16.014a.994.994 0 0 1-.993.993H3.993A.994.994 0 0 1 3 21.007V4.993C3 4.445 3.445 4 3.993 4H6Zm2-2h8v4H8V2Z"
        />
    </svg>
)

export default clipboard
