export { IconWarning } from "./IconWarning"
export { IconSuccess } from "./IconSuccess"
export { IconTrash } from "./IconTrash"
import Icon from "./Icon"

export default Icon
