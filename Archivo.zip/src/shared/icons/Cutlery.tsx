import React from 'react'
import { IconProps } from './interfaces/IconProps.interface'

const Cutlery = ({ color, ...props }: IconProps) => {
    return (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
            <g clipPath="url(#clip0_252_14809)">
                <path d="M21 2V22H19V14H16V7C16 5.67392 16.5268 4.40215 17.4645 3.46447C18.4021 2.52678 19.6739 2 21 2ZM9 13.9V22H7V13.9C5.87081 13.6691 4.85599 13.0554 4.12714 12.1625C3.3983 11.2697 3.00014 10.1526 3 9V3H5V10H7V3H9V10H11V3H13V9C12.9999 10.1526 12.6017 11.2697 11.8729 12.1625C11.144 13.0554 10.1292 13.6691 9 13.9Z" fill={color || "#000"} />
            </g>
            <defs>
                <clipPath id="clip0_252_14809">
                    <rect width="24" height="24" fill={color || "#000"} />
                </clipPath>
            </defs>
        </svg>

    )
}

export default Cutlery