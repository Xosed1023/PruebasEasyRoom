import React from "react"
import { IconProps } from "./interfaces/IconProps.interface"

const SuitcaseFill = (props: IconProps) => {
    return (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
            <g clipPath="url(#clip0_2746_4277)">
                <path
                    d="M15 3C15.552 3 16 3.448 16 4V6H21C21.552 6 22 6.448 22 7V20C22 20.552 21.552 21 21 21H3C2.448 21 2 20.552 2 20V7C2 6.448 2.448 6 3 6H8V4C8 3.448 8.448 3 9 3H15ZM8 8H6V19H8V8ZM18 8H16V19H18V8ZM14 5H10V6H14V5Z"
                    fill={props.color || "#fff"}
                />
            </g>
            <defs>
                <clipPath id="clip0_2746_4277">
                    <rect width="24" height="24" fill={props.color || "#fff"} />
                </clipPath>
            </defs>
        </svg>
    )
}

export default SuitcaseFill
