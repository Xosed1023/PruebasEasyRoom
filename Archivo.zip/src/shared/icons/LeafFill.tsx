import React from "react"
import { IconProps } from "./interfaces/IconProps.interface"

const LeafFill = (props: IconProps) => {
    return (
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
            <g clipPath="url(#clip0_417_10367)">
                <path
                    d="M14 2V3.33333C14 9.75133 10.418 12.6667 6 12.6667H4.732C4.87333 10.6587 5.49867 9.44333 7.13067 7.99933C7.93333 7.28933 7.86533 6.87933 7.47 7.11467C4.74733 8.73467 3.39533 10.924 3.33533 14.42L3.33333 14.6667H2C2 13.758 2.07733 12.9333 2.23067 12.1787C2.07733 11.316 2 10.1453 2 8.66667C2 4.98467 4.98467 2 8.66667 2C10 2 11.3333 2.66667 14 2Z"
                    fill={props.color || "#000"}
                />
            </g>
            <defs>
                <clipPath id="clip0_417_10367">
                    <rect width="16" height="16" fill="white" />
                </clipPath>
            </defs>
        </svg>
    )
}

export default LeafFill
