import cx from "classnames"
import { useData } from "./hooks/data"
import Skeleton from "src/shared/components/layout/skeleton/Skeleton"
import ImageLogo from "src/shared/icons/Image"
import CarouselGroup from "./components/carousel-group"
import DateSection from "./components/date"
import Image from "./components/Image"
import Card from "./components/Card"
import "./Disponibilidad.css"

function Disponibilidad(): JSX.Element {
    const { loading, logo, items, img_promo } = useData()
    return (
        <div className="disp__screen">
            <div className="disp__content">
                <div className="disp__card-section">
                    <CarouselGroup>
                        {items.map((group, index) => (
                            <div className="disp__card-list" key={index}>
                                {group.map((item, key) => (
                                    <Card key={key} logo={logo} {...item} />
                                ))}
                            </div>
                        ))}
                    </CarouselGroup>
                </div>
                <div className="disp__notices">
                    <div
                        className={cx({
                            "disp__notices-column": true,
                            "disp__notices-column__logo": !!logo,
                        })}
                    >
                        <div className="disp__notices-section">
                            {loading ? (
                                <Skeleton.Item className="disp__skeleton" />
                            ) : true ? (
                                <CarouselGroup>
                                    <Image src={img_promo} />
                                </CarouselGroup>
                            ) : (
                                <ImageLogo height={164} width={182} />
                            )}
                        </div>
                        <div className="disp__notices-section">
                            {loading ? (
                                <Skeleton.Item className="disp__skeleton" />
                            ) : true ? (
                                <CarouselGroup>
                                    <Image
                                        className="disp__notes-img"
                                        src="https://firebasestorage.googleapis.com/v0/b/tests-f3167.appspot.com/o/images%2Fmessage.png?alt=media&token=0e85bfaa-67f2-4aa7-bd6b-6ed2deb0260f"
                                    />
                                </CarouselGroup>
                            ) : (
                                <ImageLogo height={100} width={120} />
                            )}
                        </div>
                        {true && <DateSection />}
                    </div>
                    {logo && <img className="disp__logo" height={62} src={logo} />}
                </div>
            </div>
        </div>
    )
}

export default Disponibilidad
