export const tabs = [
    { label: "Hospedaje", path: "/hospedaje" },
    { label: "Alimentos y Bebidas", path: "/restaurant" },
]
