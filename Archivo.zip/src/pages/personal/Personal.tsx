import Screen from "src/shared/components/layout/screen/Screen"
import KanbanBoard from "./components/Board/KanbanBoard/KanbanBoard"
import { Button } from "src/shared/components/forms"
import { useNavigate } from "react-router-dom"
import { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { RootState } from "src/store/store"
import { useProfile } from "src/shared/hooks/useProfile"
import {
    EstadosTurno,
    useActualizarColaboradorTurnoMutation,
    useColaboradoresPorHotelQuery,
    useGetPuestosByHotelIdQuery,
    useGetTurnosQuery,
} from "src/gql/schema"
import { parseTimeString } from "src/shared/helpers/parseTimeString"
import { formatTime12hrs } from "src/shared/helpers/formatTime12hrs"
import { setColaboradores } from "src/store/personal/personal.slice"

import profileDefault from "src/assets/webp/profile_default.webp"

import "./Personal.css"
import useSnackbar from "src/shared/hooks/useSnackbar"
import EmptyState from "src/shared/components/layout/empty-state/EmptyState"
import DrawerSection from "./sections/DrawerSection/DrawerSection"
import { Puestos } from "src/constants/puestos"

function Personal() {
    const { showSnackbar } = useSnackbar()

    const { colaboradores } = useSelector((state: RootState) => state.personal)
    const dispatch = useDispatch()
    const { hotel_id, usuario_id, rolName } = useProfile()

    const { data: turnos, loading: turnosLoading, refetch: refetchTurnos } = useGetTurnosQuery({
        variables: {
            hotel_id,
        },
    })

    const { data: puestos } = useGetPuestosByHotelIdQuery()

    const [actualizarTurnoColaborador] = useActualizarColaboradorTurnoMutation()

    const {
        data: colaboradoresFromFetch,
        loading: colaboradoresLoading,
        refetch: refetchColaboradores,
    } = useColaboradoresPorHotelQuery({
        variables: {
            hotel_id,
        },
        fetchPolicy: "no-cache",
    })

    const cambiarTurnoColaborador = ({
        prevTurnoId,
        newTurnoId,
        colaborador_id,
        colaborador,
        turno,
    }: {
        prevTurnoId: string
        newTurnoId: string
        colaborador_id: string
        colaborador?: {
            columnId: string
            id: string
            img: string
            job: string
            name: string
        }
        turno?: {
            hora_entrada?: string
            hora_salida?: string
            id?: string
            title?: string
        }
    }) => {
        actualizarTurnoColaborador({
            variables: {
                datos_turno_colaborador: {
                    colaborador_id,
                    turno_id: newTurnoId,
                    usuario_id,
                },
            },
        })
            .then(() => {
                showSnackbar({
                    title: "Personal ha cambiado de turno",
                    status: "success",
                    text: `Cambiaste el turno de **${colaborador?.name}** a **${turno?.title} de ${formatTime12hrs(
                        turno?.hora_entrada || ""
                    )} a ${formatTime12hrs(turno?.hora_salida || "")}**`,
                })
            })
            .catch(() => {
                showSnackbar({
                    title: "Error al cambiar de turno",
                    status: "error",
                    text: "¡Ups! Se ha producido un error. Por favor, inténtalo nuevamente",
                })
            })
            .finally(() => refetchColaboradores())
    }

    const [turnosEditable, setTurnosEditable] = useState(turnos)
    const [colaboradoresEditable, setColaboradoresEditable] = useState(colaboradores)

    useEffect(() => {
        setTurnosEditable(turnos)
    }, [turnos])

    useEffect(() => {
        setColaboradoresEditable(colaboradores)
    }, [colaboradores])

    useEffect(() => {
        dispatch(setColaboradores(colaboradoresFromFetch?.colaboradores))
    }, [colaboradoresFromFetch])

    const navigate = useNavigate()
    return (
        <Screen
            title="Personal en turno"
            contentClassName="personal-screen"
            headerRight={
                (rolName !== "RECEPCIONISTA") &&
                <Button text="Administrar personal" theme="secondary" onClick={() => navigate("/u/tablePerson")} />
            }
        >
            {turnos?.turnos.length || turnosLoading || colaboradoresLoading ? (
                <>
                    <div className="personal-header-board">
                        {turnos?.turnos
                            // crear copia del arreglo
                            ?.map((t) => t)
                            // ordenar turnos por horario
                            ?.sort(
                                (a, b) =>
                                    parseTimeString(a.hora_entrada).getTime() -
                                    parseTimeString(b.hora_entrada).getTime()
                            )
                            ?.map((t) => (
                                <div className="personal-header-board-card" key={t.turno_id}>
                                    <div className="personal-header-title-container">
                                        <p className="personal-header-title">{t.nombre}</p>
                                        {t.estado === EstadosTurno.Abierto && (
                                            <p className="personal-header-turn">En turno</p>
                                        )}{" "}
                                    </div>
                                    <p className="personal-header-time">{`${formatTime12hrs(
                                        t.hora_entrada
                                    )} a ${formatTime12hrs(t.hora_salida)}`}</p>
                                </div>
                            ))}
                    </div>
                    <KanbanBoard
                        puestos={puestos?.puestos.filter(p => p.nombre === Puestos.MANTENIMIENTO || p.nombre === Puestos.RECAMARISTA) || []}
                        onSwapTurnoOpen={() => {
                            refetchTurnos()
                            refetchColaboradores({
                                hotel_id,
                            })
                        }}
                        admin={true}
                        loading={turnosLoading || colaboradoresLoading}
                        reload={() =>
                            refetchColaboradores({
                                hotel_id,
                            })
                        }
                        startCols={
                            turnosEditable?.turnos
                                ?.map((t) => ({
                                    id: t.turno_id,
                                    title: t.nombre,
                                    hora_entrada: t.hora_entrada,
                                    hora_salida: t.hora_salida,
                                    estado: t.estado,
                                }))
                                .sort(
                                    (a, b) =>
                                        parseTimeString(a.hora_entrada).getTime() -
                                        parseTimeString(b.hora_entrada).getTime()
                                ) || []
                        }
                        startTasks={
                            colaboradoresEditable
                                ?.filter(c => (c?.colaborador_in_hotel?.[0]?.puesto?.nombre === Puestos.MANTENIMIENTO || c.colaborador_in_hotel?.[0]?.puesto?.nombre === Puestos.RECAMARISTA))
                                ?.map((c) => ({
                                    columnId: c.turno.turno_id,
                                    id: c.colaborador_id,
                                    img: c.foto || profileDefault,
                                    job: c?.colaborador_in_hotel?.[0]?.puesto?.nombre || "",
                                    habitacionUltimaTarea: c.ultima_tarea ? 
                                        c.ultima_tarea.fecha_termino ?
                                        "Sin asignar" :    
                                        `${c?.ultima_tarea?.habitacion?.tipo_habitacion?.nombre} ${c.ultima_tarea?.habitacion?.numero_habitacion}` : 
                                        "Sin asignar",
                                    name: `${c.nombre} ${c.apellido_paterno} ${c.apellido_materno}`,
                                    active: c.en_turno,
                                    idAsistencia: c.asistencia_abierta?.asistencia_id || "",
                                    // Este valor se establece en ColumnContainer, dado que tiene que ver su columna para conocer este valor
                                    isInTurnoActual: false,
                                    colaborador: c,
                                    hasTareaActiva: c.ultima_tarea ? !c.ultima_tarea?.fecha_termino : false
                                })) || []
                        }
                        onDrag={({ column, task }) => {
                            const updatedColaboradoresEditable = colaboradoresEditable?.map((c) => {
                                if (task?.id === c.colaborador_id) {
                                    return {
                                        ...c,
                                        turno: {
                                            ...c.turno,
                                            nombre: column?.title || "",
                                            hora_entrada: column?.hora_entrada || "",
                                            hora_salida: column?.hora_salida || "",
                                            turno_id: column?.id || "",
                                        },
                                    }
                                }
                                return c
                            })
                            cambiarTurnoColaborador({
                                prevTurnoId: task?.columnId || "",
                                colaborador_id: task?.id || "",
                                colaborador: task,
                                turno: column,
                                newTurnoId: column?.id || "",
                            })
                            setColaboradoresEditable(updatedColaboradoresEditable)
                        }}
                        onConfirmSearch={({ column, task }) => {
                            const updatedColaboradoresEditable = colaboradoresEditable?.map((c) => {
                                if (task?.id === c.colaborador_id) {
                                    return {
                                        ...c,
                                        turno: {
                                            ...c.turno,
                                            nombre: column?.title || "",
                                            hora_entrada: column?.hora_entrada || "",
                                            hora_salida: column?.hora_salida || "",
                                            turno_id: column?.id || "",
                                        },
                                    }
                                }
                                return c
                            })
                            cambiarTurnoColaborador({
                                prevTurnoId: task?.columnId || "",
                                colaborador_id: task?.id || "",
                                colaborador: task,
                                turno: column,
                                newTurnoId: column?.id || "",
                            })
                            setColaboradoresEditable(updatedColaboradoresEditable)
                        }}
                    />
                </>
            ) : (
                <div className="personal-header-board--empty">
                    <EmptyState
                        title="Sin personal registrado"
                        subtitle="Comienza a registrar al personal de tu hotel aquí"
                        headerIcon="UserPlus"
                    />
                    <Button
                        text="Agregar personal"
                        theme="primary"
                        className="personal-header-board--empty__add"
                        onClick={() => navigate("/u/addPerson")}
                    />
                </div>
            )}
            <DrawerSection  />
        </Screen>
    )
}

export default Personal
