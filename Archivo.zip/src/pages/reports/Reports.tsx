import Screen from "src/shared/components/layout/screen/Screen"
import { useFetch } from "src/shared/hooks/useFetch"

const Reports = () => {

    const {data} = useFetch("/reportes/tabla_productividad_camaristas", {
        variables: {

        }
    })
    const {data: dataVenta} = useFetch("/reportes/tabla_venta_articulos")

    console.log({data, dataVenta});
    

    return (
        <Screen title="Reportes">
            <div>Reportes</div>
        </Screen>
    )
}

export default Reports
