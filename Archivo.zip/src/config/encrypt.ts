export const REACT_AUTH_KEY = process.env.REACT_APP_AUTH_KEY
