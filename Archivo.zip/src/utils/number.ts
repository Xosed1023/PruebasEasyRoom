export const getNumber = (number: any) => {
    return Number(number) || 0
}
