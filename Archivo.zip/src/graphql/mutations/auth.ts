import { gql } from "@apollo/client"

export const LOGIN = gql`
    mutation Login($loginInput: AuthLoginInput!) {
        login(loginInput: $loginInput) {
            token
        }
    }
`

export const LOGOUT = gql`
    mutation Logout {
        logout
    }
`
